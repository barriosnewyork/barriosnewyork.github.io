// Year in footer
document.getElementById('y').textContent = new Date().getFullYear();

// Contact form success banner (demo)
const form = document.getElementById('contactForm');
form.addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('sent').hidden = false;
});
